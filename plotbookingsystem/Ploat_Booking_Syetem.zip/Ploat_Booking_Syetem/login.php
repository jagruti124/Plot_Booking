<?php
$con =mysqli_connect('localhost','root');
if($con)
{
}
else
{
echo"No connection";
}

	mysqli_select_db($con,'plotbookingsystem');

// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: index.php");
    exit;
}
 
if(isset($_POST['submit'])){
	$name = $_POST['uname'];
	$pass = $_POST['pass'];
	$query = "select * from registration where fname='$name' and pass='$pass'";
	$result = mysqli_query($con, $query);
	
	$count = mysqli_num_rows($result);
	
	if($count == 1){
		header("location: index.php");
	}
	else{
		echo "Failed";
	}
	
	
}

 ?>
  
<!DOCTYPE html>
<html>

<head>
         </div>
		 <div>
    <title>Ploat Booking System</title>
    <meta charset="utf-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style">
  <!-- bootstrap css -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  
  <!-- google font -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  

<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

*{
	margin : 0;  padding : 0; box-sizing : border-box;
	
}

body {font-family: Arial, Helvetica, sans-serif;}
form {border: 2px solid #f1f1f1;}


		



input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 2px solid #ccc;
  box-sizing: border-box;
}
 background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 5px 9px;
  background-color: #f44336;
}

.imgcontainer {
  text-align: center;
  margin: 12px 0 6px 0;
}

img.avatar {
  width: 20%;
  border-radius: 25%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 150px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}

</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="index.php"><div class="container-fluid">
		Ploat Booking System</div></a>
  <span class="navbar-text"> </span>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="myMenu">
  <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="myMenu">
      <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php"><h5>Home</h5></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="properties.php"><h5>Property</h5></a>
      </li>
      
	  <li class="nav-item">
        <a class="nav-link" href="listing.php"><h5>listing</h5></a>
			<a  href="listing.php"></a>
      </li>
	  
	  
<li class="nav-item">
        <a class="nav-link" href="map.php"><h5>Map</h5></a>
			<a  href="map.php"></a>
      </li> 

	  
	  <li class="nav-item">
        <a class="nav-link" href="signup.php"><h5>signup</h5></a>
		<a  href="signup.php"></a>
      </li>
	  
	 
    <li class="nav-item">
        <a class="nav-link" href="logout.php"><h5>logout</h5></a>
			<a  href="logout.php"></a>
      </li>      

     
    </ul>
   
  </div>
</nav>


<h2>Login Form</h2>
<div class= "col-lg-6">
<form method="post">
  <div class="imgcontainer">
    <img src="images/plot(9).jfif" alt="" class="">
  </div>

  <div class="container">
    <label for="username"><b>username</b></label>
    <input type="text" placeholder="Enter Username" name="uname" required>
     <br></br>
	 
    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="pass" required>
        <br></br></div>
		
		<div>
    <input type="submit"name="submit"value="submit"class="btn btn-success"> 
	<br></br></div>
	
    <label>
      <input type="checkbox" checked="checked" name="remember"> Remember me
    </label>
  
  
<br></br>
  <div class="container" style="background-color:#">
    <button type"Cancel" class="btn btn-success">Cancel</button>
    <span class="psw">Reset <a href="resetpassword.php">password?</a></span>
  </div>
</form>
</div>

</body>
</html>


<!DOCTYPE html>
<html>

<head>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- jQuery library -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</head>
<body>
  
  
  <div class="col-ig-8 m-auto d-block">
  <div class ="w-50 m-auto">
  <div class "container"><br>
  

  </div></div></div>
  <br></br><br></br><br></br><br></br>
  <section>
<div>
<footer Class>
   
<h3 class ="p-5 bg-dark text-white"></h3>
 
</footer>
</div>
</section>

  
</body>
</html>


