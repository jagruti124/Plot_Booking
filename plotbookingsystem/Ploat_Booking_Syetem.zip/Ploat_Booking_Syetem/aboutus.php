

<!DOCTYPE html>
<html>
<head><title></title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel ="stylesheet" type ="text/css"href="style.css/all_min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</head>
<body>
      <!doctype html>
<html lang="en">
  <head>
      
         </div>
    <title>Ploat Booking System</title>
    <meta charset="utf-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style">
  <!-- bootstrap css -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  
  <!-- google font -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
   </head>
  <body>
  <!-- start navigation  -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="index.php"><div class="container-fluid">
		Ploat Booking System</div></a>
  <span class="navbar-text"> </span>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="myMenu">
  <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="myMenu">
      <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php"><h5>Home</h5></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="properties.php"><h5>Property</h5></a>
      </li>
	  
	  <li class="nav-item">
        <a class="nav-link" href="listing.php"><h5>listing</h5></a>
			<a  href="listing.php"></a>
      </li> 
	  
<li class="nav-item">
        <a class="nav-link" href="map.php"><h5>Map</h5></a>
			<a  href="map.php"></a>
      </li> 


      <li class="nav-item">
        <a class="nav-link" href="signup.php"><h5>signup</h5></a>
		<a  href="signup.php"></a>
      </li>
	  
      
	 <li class="nav-item">
        <a class="nav-link" href="login.php"><h5>Login</h5></a>
		<a  href="login.php"></a>
     </li>
    
     	 
    <li class="nav-item">
        <a class="nav-link" href="logout.php"><h5>logout</h5></a>
			<a  href="logout.php"></a>
      </li>      
	
		 
      
     
    </ul>
  </div>
</nav>

<div class="jumbotron">
  <h1>WELCOME TO OUR WEBSITE</h1>
  <p>your Dreame!</p>
</div>

<section class= "my-5">
<div class="py-5">
   <h3 class = "text-center">About us</h3>
</div>
    <div class="container-fluid">
	    <div class ="row">
		<div class="col-lg-3 col-md-3 col-6">
		<img src="images\plot(5).jpg"class=img-fluid>
		</div>
			<div class="col-lg-6 col-md-6 col-12">
		
            
<p class=" py-3"><h4>We have developed very unique online plot booking system for builders and real estate agents. Our script is very flexible and allow user to book plot as per 2-D plan. Online plot booking system is supported by strong content management system where you can manage all sales related documents along with the booking history.<h4></p>
        

			</div>
           </div>
    </div>
	</section>
	<br></br><br></br><br></br>
	
	<section>
<div>
<footer Class>
   
<h3 class ="p-5 bg-dark text-white"></h3>
 
</footer>
</div>
</section>

</body>
</html>