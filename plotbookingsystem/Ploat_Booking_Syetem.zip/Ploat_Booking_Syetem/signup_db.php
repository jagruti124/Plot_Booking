<?php
$con =mysqli_connect('localhost','root');
if($con)
{
	echo"Connection successful";
}
else
{
echo"No connection";
}
	
	mysqli_select_db($con,'plotbookingsystem');
	
	$firstname = $_POST['first_name'];
	$lastname = $_POST['last_name'];
	$email = $_POST['email'];
	$password = $_POST['pass'];
	$confirmpassword= $_POST['cpass'];
	
	if ($password == $confirmpassword){
	$query= "insert into registration(id,fname,lname,mail,pass)
	values('', '$firstname', '$lastname', '$email', '$password ')";}
	else{
		
		echo "no data found";
	}
	
    echo "$query";
	mysqli_query($con,$query);


header('location:index.php');
?>