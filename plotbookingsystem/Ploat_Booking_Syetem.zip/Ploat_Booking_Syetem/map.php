<!DOCTYPE html>
<html>

<head>

<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel ="stylesheet" type ="text/css"href="style.css/all_min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<style>

*{
	margin : 0;  padding : 0; box-sizing : border-box;
	
}</style>

</head>
<body>

<!doctype html>
<html lang="en">
  <head>
      
         </div>
    <title>Ploat Booking System</title>
    <meta charset="utf-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style">
  <!-- bootstrap css -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  
  <!-- google font -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
   </head>
  <body>
  <!-- start navigation  -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="index.php"><div class="container-fluid">
		<b>Ploat Booking System</b></div></a>
  <span class="navbar-text"> </span>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="myMenu">
  <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="myMenu">
      <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php"><h5>Home</h5></a>
      </li>
	  
	  <li class="nav-item">
        <a class="nav-link" href="aboutus.php"><h5>AboutUs</h5></a>
			<a  href="aboutus.php"></a>
      </li>  
    
	  
      <li class="nav-item">
        <a class="nav-link" href="properties.php"><h5>Property</h5></a>
      </li>
      
	  
	  <li class="nav-item">
        <a class="nav-link" href="listing.php"><h5>listing</h5></a>
			<a  href="listing.php"></a>
      </li> 

<li class="nav-item">
        <a class="nav-link" href="map.php"><h5>Map</h5></a>
			<a  href="map.php"></a>
      </li> 


      <li class="nav-item">
        <a class="nav-link" href="signup.php"><h5>signup</h5></a>
		<a  href="signup.php"></a>
      </li>
	  
	  
	 <li class="nav-item">
        <a class="nav-link" href="login.php"><h5>Login</h5></a>
		<a  href="login.php"></a>
     </li>
     		
		
    
     <li class="nav-item">
        <a class="nav-link" href="logout.php"><h5>logout</h5></a>
			<a  href="logout.php"></a>
      </li>      
     
    </ul>
    </form>
  </div>
</nav>
<br></br>
<div>
<h3>Search Property & property location on Google Map</h3>
</div><br></br>
<section>
<iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d475684.95855662756!2d76.09259174568527!3d21.339103291492606!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1splots%20in%20burhanpur%20for%20sales%20and%20buy!5e0!3m2!1sen!2sin!4v1636963685828!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
</section>

<br></br><br></br><br></br><br></br><br></br>



<section>
<footer>
  <div class="footer-copyright text-center py-3">
    <a href="https://mdbootstrap.com/"> </a>
  </div>
 
<center>
<h4 class ="p-4 bg-dark text-white">http://plotbooking.com</h4>
 
 </center>
</footer>

</section>


</body>
</html>