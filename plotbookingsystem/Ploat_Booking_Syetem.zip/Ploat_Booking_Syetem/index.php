

<!DOCTYPE html>
<html>
<head><title></title>
<style>


</style>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel ="stylesheet" type ="text/css"href="style.css/all_min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</head>
<body>
      <!doctype html>
<html lang="en">
  <head>
      
         </div>
    <title>Ploat Booking System</title>
    <meta charset="utf-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style">
  <!-- bootstrap css -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  
  <!-- google font -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
   </head>
  <body>
  <!-- start navigation  -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="index.php"><div class="container-fluid">
		<b>Ploat Booking System</b></div></a>
  <span class="navbar-text"> </span>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="myMenu">
  <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="myMenu">
      <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php"><h5>Home</h5></a>
      </li>
	  
	  <li class="nav-item">
        <a class="nav-link" href="aboutus.php"><h5>AboutUs</h5></a>
			<a  href="aboutus.php"></a>
      </li>  
    
	  
      <li class="nav-item">
        <a class="nav-link" href="properties.php"><h5>Property</h5></a>
      </li>
      
	  
	  <li class="nav-item">
        <a class="nav-link" href="listing.php"><h5>listing</h5></a>
			<a  href="listing.php"></a>
      </li> 

<li class="nav-item">
        <a class="nav-link" href="map.php"><h5>Map</h5></a>
			<a  href="map.php"></a>
      </li> 


      <li class="nav-item">
        <a class="nav-link" href="signup.php"><h5>signup</h5></a>
		<a  href="signup.php"></a>
      </li>
	  
	  
	 <li class="nav-item">
        <a class="nav-link" href="login.php"><h5>Login</h5></a>
		<a  href="login.php"></a>
     </li>
     		
		
    
     <li class="nav-item">
        <a class="nav-link" href="logout.php"><h5>logout</h5></a>
			<a  href="logout.php"></a>
      </li>      
     
    </ul>
    </form>
  </div>
</nav>

   

   <header 
  
      <div>
         <h3 style="text-align:center"><b>WELCOME TO OUR WEBSITE</b></h3>
        
		<p>your Dreame!</p>
   </div>
</header>
      </div>   
    </div>
	<div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
                
    </div>
	    
       
        <div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/plot(2).jpg" alt="" width="1100" height="700">
      <div class="carousel-caption">
        
        <p>We have such a grate plots</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="images/plot(1).jpg" alt="" width="1100" height="700">
      <div class="carousel-caption">
        
      </div>   
    </div>
    <div class="carousel-item">
      <img src="images/plot(3).jpg" alt="" width="1100" height="700">
      <div class="carousel-caption">
        
      </div>   
    </div>
  </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
  
  <section class= "my-3">
  <div class="py-3">
   <h4 class = "text-center">About us</h4>
</div>
    <div class="container-fluid">
	    <div class ="row">
		<div class="col-lg-3 col-md-3 col-6">
		<img src="images\plot(5).jpg"class=img-fluid>
		</div>
			<div class="col-lg-6 col-md-6 col-12">
		
            
<p class=" py-3"><h4>We have developed very unique online plot booking system for builders and real estate agents. Our script is very flexible and allow user to book plot as per 2-D plan. Online plot booking system is supported by strong content management system where you can manage all sales related documents along with the booking history.<h4></p>
        

			</div>
           </div>
    </div>
	</section>
	
	<section>
    <div class="py-3">
	<h2 class ="text-center">Our Servises</h2>
	</div>
	<div class="container-fluid">
	<div class="row">
			<div class="col-lg-3 col-md-3 col-6">
		<img src="images\plot(10).jpg"class=img-fluid>
		</div>
	<div class="col-lg-4 col-lg-4 col-12">
<div>	
  <style>


p {
  font-size: 25px;
}
</style>

	<p>
	Admin can upload any size and shape of layout.
	</p>
   
	


	<p>
Plot size can be any shape Eg-Square, rectangle, circle, polygon etc.
</p>
   
	<p>

Admin can set each plot size separately (Super buildup area, Carpet area)Admin can add various categories for same shape and size plot.
</p>
  

	<p>
User will get price based on area of a particular plot, it means admin can set different-different price for all plots.
</p>
   </div>

	</div>
	</div>
	</div>
	</section>

<section class="my-5">
<div class="py-5">
   <h2 class="text-center py-5">propertys for sale </h2>
    <div class="row ">
	

	 <div class="col-lg-4"> 
       <div class="card">
       <img src="images/plot(6).jpg" alt="" width="735" height="500">
        <input type="button" class="btnc" value="SALE">
        <h5 class="p-3 font-weight-bold">RS.</h5>
           <p class="px-3"> Buying and selling Plot with a realtor is a rather complicated segment of the real state market.</p>
         
       </div>
    </div>

    <div class="col-lg-4 "> 
       <div class="card">
       <img src="images/plot(7).jpg" alt="" width="735" height="500">
        <input type="button" class="btnc" value="SALE">
        <h5 class="p-3 font-weight-bold">RS.</h5>
           <p class="px-3">Buying and selling Plot  with a realtor is a rather complicated segment of the real state market.</p>
       </div>
        </div>
        <div class="col-lg-4">
       <div class="card">
       <img src="images/plot(8).jpeg" alt="" width="735" height="500">
        <input type="button" class="btnc" value="SALE">
        <h5 class="p-3 font-weight-bold">RS.</h5>
           <p class="px-3"> Buying and selling Plot with a realtor is a rather complicated segment of the real state market.</p>
       
        </div>
    </div>
    </div>
   </div>
  </section>
  
<section>
<div class ="w-50 m-auto">
<form action ="contactus_db.php"method="post">
<h2>Contact Us</h2>

<div class=" form-group">
<label>username</label>
<input type= "text"name="user"autocomplete="off"class="form-control">
</div>
 
 <div class=" form-group">
<label>email</label>
<input type= "text"name="email"autocomplete="off"class="form-control">
</div>

<div class=" form-group">
<label>mobile</label>
<input type= "text"name="mobile"autocomplete="off"class="form-control">
</div>

<div class=" form-group">
<label>comments</label>
<textarea class=" form-control"name="comments">
</textarea>
</div>
    <button type"submit" class="btn btn-success">submit</button>
	
</form>
</div>

</section>
<br></br>

 
  <div class="footer-copyright text-center py-3">
    <a href="https://mdbootstrap.com/"> </a>
  </div>
 
<center>
<h4 class ="p-4 bg-dark text-white">http://plotbooking.com</h4>
 </center>
 
</footer>
</div>
</section>
  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/bootstrape.min.js"></script>
  
  
  
  
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  
</body>
</html>