<!DOCTYPE html>
<html lang="en">
<head>

<style>

*{
	margin : 0;  padding : 0; box-sizing : border-box;
	
}</style>



<title></title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel ="stylesheet" type ="text/css"href="style.css/all_min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
<title>Welcome to our website</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="assests/css/style.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="index.php"><div class="container-fluid">
		Ploat Booking System</div></a>
  <span class="navbar-text"> </span>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="myMenu">
  <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="myMenu">
      <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php"><h5>Home </h5></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="properties.php"><h5>Property</h5></a>
      </li>
	  
	  	
		<li class="nav-item">
        <a class="nav-link" href="listing.php"><h5>listing</h5></a>
			<a  href="listing.php"></a>
      </li>  
	  
	  
<li class="nav-item">
        <a class="nav-link" href="map.php"><h5>Map</h5></a>
			<a  href="map.php"></a>
      </li> 

      
     <li class="nav-item">
        <a class="nav-link" href="login.php"><h5>Login</h5></a>
		<a  href="login.php"></a>
     </li>
	 
	 	
    
     <li class="nav-item">
        <a class="nav-link" href="logout.php"><h5>logout</h5></a>
			<a  href="logout.php"></a>
      </li>      
     
    
     </ul>
      </div>
</nav>




<div class="signup-form">
    <form action="signup_db.php" method="post" enctype="multipart/form-data">
		<h2>Register</h2>
		<p class="hint-text">Create your account</p>
		
        <div class="form-group">
		
		 <div class="col-lg-6">
		 
        <input type="text" class="form-control" name="first_name" placeholder="First Name" required="required">
		</div>
		<br></br>
		
				<div>
				<div class="col-lg-6">
				
				<input type="text" class="form-control" name="last_name" placeholder="Last Name" required="required"></div>
			</div>        	
        
		</div>
		<br></br>
        <div class="form-group">
		<div class="col-lg-6">
		
        	<input type="email" class="form-control" name="email" placeholder="Email" required="required">
        </div></div>
		<br></br>
		
		<div class="form-group">
		<div class="col-lg-6">
	
            <input type="password" class="form-control" name="pass" placeholder="Password" required="required">
        </div></div>
		
		<br></br>
		<div class="form-group">
		<div class="col-lg-6">
		
            <input type="password" class="form-control" name="cpass" placeholder="Confirm Password" required="required">
        </div></div></div>
               
        <div class="form-group">
		<div class="col-lg-6">
			<label class="form-check-label"><input type="checkbox" required="required"> I accept the <a href="#">Terms of Use</a> & <a href="#">Privacy Policy</a></label>
		</div></div>
		
		<div class="form-group">
		<div class="col-lg-6">
            <button type="submit" name="save" class="btn btn-success btn-lg btn-block">Register Now</button>
        </div>
		</div>
		
        <div class="">Already have an account? <a href="login.php">login</a></div>
    </form>
	
</div>
 <br></br> <br></br> <br></br> <br></br> <br></br> <br></br>
<section>
<div>
<footer Class>
   
<h3 class ="p-5 bg-dark text-white"></h3>
 
</footer>
</div>
</section>


</body>
</html>


























