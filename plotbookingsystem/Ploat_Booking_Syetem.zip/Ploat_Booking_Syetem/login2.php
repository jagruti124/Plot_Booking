<?php
$con =mysqli_connect('localhost','root');
if($con)
{
}
else
{
echo"No connection";
}

	mysqli_select_db($con,'plotbookingsystem');

// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: index.php");
    exit;
}
 
if(isset($_POST['submit'])){
	$name = $_POST['uname'];
	$pass = $_POST['pass'];
	$query = "select * from registration where fname='$name' and pass='$pass'";
	$result = mysqli_query($con, $query);
	
	$count = mysqli_num_rows($result);
	
	if($count == 1){
		header("location: index.php");
	}
	else{
		echo "Failed";
	}
	
	
}
